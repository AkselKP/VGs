module.exports = {
  files: [
    'tests/kalkulator.test.js'
  ]
}

/**
 * Bruk denne når du jobber med harjegfri
 * module.exports = {
  files: [
    'tests/harjegfri.test.js'
  ]
}
 */
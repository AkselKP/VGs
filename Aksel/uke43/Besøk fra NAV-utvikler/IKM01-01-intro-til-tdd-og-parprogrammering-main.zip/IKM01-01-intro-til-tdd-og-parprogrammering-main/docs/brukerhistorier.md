# Brukerhistorier til verdens kuleste funksjon

- som bruker ønsker jeg å få "ja" fra funksjonen slik at jeg kan kose meg hjemme
- som bruker ønsker jeg å få "ja" dersom jeg har fri i dag og "nei" hvis ikke slik at jeg vet om jeg kan bli hjemme eller ikke
- som bruker ønsker jeg å få "ja" dersom jeg har fri i morgen og "nei" hvis jeg ikke har det slik at jeg vet om jeg kan være hjemme eller ikke
- som bruker ønsker jeg å kunne sende inn en hvilken som helst dato i år og få "ja" dersom jeg har fri den dagen og "nei" hvis ikke slik at jeg vet om jeg kan være hjemme eller ikke
- som bruker ønsker jeg å kunne sende inn en hvilken som helst dato i 2020 eller 2021 og få "ja" tilbake om jeg har fri den dagen og "nei" hvis ikke slik at jeg vet om jeg kan kose meg hjemme.

## Tips til datoer som kan/bør testes

- 01. oktober 2020 - nei
- 04. oktober 2020 - ja (søndag)
- 05. oktober 2020 - ja (er høstferie)
- 20. oktober 2020 - nei
- 09. mars 2021 - ja (planleggingsdag)
- 21. juni 2021 - ja (sommerferie)